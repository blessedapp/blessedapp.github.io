# Blessed — apresentação de negócio

Preparada para uma reunião de aproximadamente dez minutos, em 22/10/2026.

- `output/Blessed-Plano-de-Negocio.pptx`: PowerPoint editável, 20 slides principais e 7 anexos. Todos os slides têm notas.
- `output/Blessed-Plano-de-Negocio.pdf`: a mesma apresentação, exportada com capturas sem redução de resolução.
- `output/Blessed-Roteiro-10-minutos.pdf`: fala sugerida e respostas para perguntas.
- `output/Blessed-Custos-e-Cenarios.xlsx`: premissas, receita, infraestrutura e ponto de equilíbrio editáveis, com fórmulas recalculadas.

Apresentador: desenvolvedor do Blessed. Valor de investimento, participação e instrumento de captação ficam em aberto.

## Como apresentar

Apresente os slides 1 a 20. Pare no convite final. Os sete anexos existem para as perguntas. O roteiro tem 9min40s de fala planejada; deixe cerca de vinte segundos de margem.

## Critérios e limites

As imagens são capturas do código atual do app, feitas em 1170 × 2532 pixels, e recortes dos próprios painéis. Não foi usado gerador de imagens. Não há usuários ativos, receita, contratos ou retorno de investimento inventados.

Perfis e publicações vieram da vitrine pública. Áreas autenticadas foram renderizadas em sessão local de demonstração, sem consultar mensagens privadas nem criar contas ou transações na produção. O saldo sem movimentações é demonstrativo. As fotografias já existentes dentro das telas pertencem ao conteúdo do aplicativo; não são fotografias novas produzidas para a apresentação. A capa R2 de cinema não pôde ser obtida neste ambiente: o material mostra o seletor de formatos e os metadados públicos da produção.

O módulo comercial não está completo: cadastro de portfólio/interesses, perfis e chat existem; a busca de portfólios pelas empresas, solicitação estruturada, contratação e pagamentos precisam ser concluídos. Saques e cobrança do Cine não estão ativados.

A segurança é descrita a partir do projeto e das políticas SQL revisadas. HTTPS/TLS não é criptografia ponta a ponta. Não houve auditoria independente de produção e não se apresenta certificação de terceiros.

As faixas de manutenção são orçamentos ilustrativos e não faturas reais. O câmbio de R$ 6,00 por dólar é uma premissa. Custos de pessoas, moderação, aquisição, jurídico, tributos e pagamentos devem ser orçados além da infraestrutura.

## Fontes

- Projeto privado Blessed, versão `bb28636`.
- API de vitrine pública da comunidade e catálogo público, consultados em 22/10/2026. A amostra retornou 22 perfis, 21 posts e um título de cinema; não constitui MAU nem total de contas.
- https://github.com/supabase/supabase/blob/master/packages/shared-data/plans.ts
- https://github.com/supabase/supabase/blob/master/packages/shared-data/pricing.ts
- https://developers.cloudflare.com/r2/pricing/
- https://developers.cloudflare.com/workers/platform/pricing/

Os arquivos de `src/` geram o material. Consultas de vitrine e capturas são somente de leitura e não publicam nada no aplicativo.
