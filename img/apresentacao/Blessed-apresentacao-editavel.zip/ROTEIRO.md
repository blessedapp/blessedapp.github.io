# Blessed · Apresentação completa

Duração: 3:40. Formato: 1920 × 1080, 30 fps.

Trilha instrumental original, criada para esta apresentação. Sem músicas comerciais e sem locução nesta versão.

Os perfis, mensagens e contagens são demonstrações. As telas foram capturadas do aplicativo atual com serviços simulados, sem acesso às conversas reais.

## 0:00 — abertura
Sua fé. Mais perto.
Comunidade, louvor e vida com Deus. Tudo começa com uma conexão.
Recursos: Comunidade e louvor.

## 0:08 — inicio
A comunidade vem primeiro.
Um lugar para encontrar pessoas, compartilhar a fé e caminhar junto.
Recursos: Pessoas, Músicos, Igrejas.

## 0:17 — publicacoes
Compartilhe o seu momento.
Fotos, textos e encontros que continuam além do culto.
Recursos: Publicar, Curtir e comentar, Salvar e compartilhar.

## 0:29 — pessoas
Encontre quem caminha com você.
Siga músicos, conheça membros e esteja perto da sua igreja.
Recursos: Buscar pessoas, Seguir perfis, Horários da igreja.

## 0:39 — perfil
Seu perfil. Sua história.
Foto, capa e identidade. Sua comunidade conhece você.
Recursos: Fotos, Seguidores, Seguindo.

## 0:47 — stories
Momentos que ganham uma trilha.
Uma foto. Um trecho de música. Um pouco do seu dia.
Recursos: Música no story, Visto por, Curtido por.

## 0:59 — blessings
Pequenos vídeos. Grandes momentos.
Trechos de ensaios, louvor e experiências para compartilhar.
Recursos: Vídeos curtos, Curtir, Comentar e compartilhar.

## 1:07 — direct
Mais perto, numa mensagem.
Da primeira conversa ao próximo encontro.
Recursos: Mensagens privadas, Avisos de novas mensagens.

## 1:16 — midias
Escreva. Mostre. Deixe sua voz.
Envie uma foto da galeria ou grave um áudio para ouvir antes.
Recursos: Fotos com legenda, Áudios de até 2 minutos, Prévia antes de enviar.

## 1:28 — chamar
Tem alguém chamando você.
O nome aparece. A tela balança. A conversa ganha vida.
Recursos: Chamar atenção, Som e movimento.

## 1:36 — fundo
Seu fundo. Seu jeito.
Escolha uma foto da galeria para o papel de parede do Direct.
Recursos: Por conversa, Só para você, Salvo neste aparelho.

## 1:44 — modelos
Quatro modelos. Seu próprio ritmo.
Planeje a semana ou organize o dia.
Recursos: Semanal colorida, Diária rosé, Oceano, Grafite.

## 1:58 — escrita
Toque. Escreva. Deixe sua marca.
Escolha a cor da caneta e veja a anotação ganhar a página.
Recursos: Blocos e linhas editáveis, Cores de caneta, Salvo neste aparelho.

## 2:08 — artistas
Sua próxima canção começa aqui.
Encontre artistas e músicas para acompanhar sua caminhada.
Recursos: Artistas, Busca por música, Repertório.

## 2:16 — cifras
O tom muda. A inspiração fica.
Cifras, transposição e instrumentos para acompanhar seu momento.
Recursos: Mudar o tom, Teclado e violão, Acordes e graus.

## 2:28 — escala
Organize o próximo louvor.
Prepare as músicas na ordem em que serão tocadas.
Recursos: Escala do culto, Reordenar músicas, Acesso ao repertório.

## 2:36 — harmonia
Aprender também é adorar.
Explore notas, acordes e caminhos da harmonia.
Recursos: Campo harmônico, Graus e acordes, Teclado e violão.

## 2:46 — biblia
Leia. Reflita. Leve com você.
Navegue pela Bíblia, selecione versículos e encontre passagens.
Recursos: Leitura bíblica, Busca e seleção, Compartilhar versículos.

## 2:56 — estudos
Sua mensagem começa na Palavra.
Organize referências, anotações e o esboço da sua pregação.
Recursos: Estudos pessoais, Referências, Modo pregação e exportação.

## 3:06 — avisos
Escolha como quer ser avisado.
Sons, mensagens e notificações com as suas preferências.
Recursos: Sons do app, Notificações, Instalar na Tela de Início.

## 3:14 — painel
Um olhar atento. No seu painel.
Acompanhe quem está online e há quanto tempo saiu.
Recursos: Contador de presença, Tempo de conexão, Lista exclusiva do dono.

## 3:22 — conta
Sua conta. Seu lugar aqui.
Confirme a senha, confira o que digitou e continue conectado neste aparelho.
Recursos: Confirmar senha, Exibir senha, Sessão salva.

## 3:30 — convite
Faça parte dessa conexão.
Comunidade e louvor. Um novo encontro, todos os dias.
Recursos: blessedapp.github.io.
